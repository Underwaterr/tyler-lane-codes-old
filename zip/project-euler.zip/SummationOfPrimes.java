
public class SummationOfPrimes 
{
    public static boolean isPrime(int a)
    {
        for (int i=2; i<a; i++)
            if (a % i == 0)
                return false;
        return true;
    }
    
    public static void main(String[] args) 
    {
        final int CONST = 100_000;
        
        int sum = 0;
        for (int i=CONST; i>=2; i--)
            if (isPrime(i))
                sum += i;
        System.out.println(sum);
        

    }

}
