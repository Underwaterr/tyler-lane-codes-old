
public class SumSquareDifference 
{
    public static int SumOfSquares()
    {
        int sum = 0;
        for (int i=1; i<=100; i++)
            sum += (i * i);
        return sum;
    }
    
    public static int SquareOfTheSum()
    {
        int sum = 0;
        for (int i=1; i<=100; i++)
            sum += i;
        return (sum * sum);
    }
    
    
    public static void main(String[] args) 
    {
        System.out.println(SumOfSquares());
        System.out.println(SquareOfTheSum());
        System.out.println(SquareOfTheSum()-SumOfSquares());
    }

}
