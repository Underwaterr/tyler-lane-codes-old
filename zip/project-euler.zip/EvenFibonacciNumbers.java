// 4613732

public class EvenFibonacciNumbers {

	public static int Fib(int a)
	{
		if (a == 0)
			return 0;
		if (a == 1)
			return 1;
		else
			return Fib(a-1) + Fib(a-2);
	}
	
	public static void main(String[] args) {

		int sum = 0;
		for (int i=0; Fib(i)<4000000; i++)
			if (Fib(i) % 2 == 0)
				sum += Fib(i);
		System.out.println(sum);
		
	}

}
