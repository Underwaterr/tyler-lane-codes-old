
public class LargestPrimeFactor {
    
    // Finds the 'first' prime factor of a
    // Returns -1 i a is prime
    public static long PrimeFactor(long a)
    {
        for (int i=2; i<a; i++)
            if (a % i == 0)             // Find a factor
                if (PrimeFactor(i) == -1)   // Is it a prime factor?
                    return i;
                else
                    return PrimeFactor(i);  // Factor until prime found
        return -1;
    }
    
    // Prints out all the prime factors of factorMe
    public static void FactorOut(long factorMe)
    {
        System.out.print(factorMe + " = ");
        while (PrimeFactor(factorMe) != -1)
        {
            System.out.print(PrimeFactor(factorMe) + " * ");
            factorMe = factorMe / PrimeFactor(factorMe);
        }
        System.out.println(factorMe);
    }
    

    public static void main(String[] args) {

        // Now for this MFKR
        FactorOut(600851475143L);
        
    }

}
