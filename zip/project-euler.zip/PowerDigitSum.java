import java.math.BigInteger;

public class PowerDigitSum
{
    
    public static void main(String[] args)
    {
        final int POWER = 1_000;
        
        BigInteger answer = new BigInteger("2");
        for (int i=1; i<POWER; i++)
        {
            answer = answer.multiply(new BigInteger("2"));
            System.out.println("2^" + (i+1) + ":\t" + answer);
        }
        
        String answerStr = answer.toString();
        System.out.println(answerStr);

        int sum = 0;
        for (int i=0; i<answerStr.length(); i++)
            sum += Character.getNumericValue(answerStr.charAt(i));
            
        System.out.println("\n\n" + sum);
    }

}
