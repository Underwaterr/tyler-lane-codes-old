
public class LargestPalindromeProduct 
{
    // Returns whether the number is a palindrome or not
    public static boolean isPalindrome(int a)
    {
        return (a == Integer.parseInt(new StringBuffer(a + "").reverse().toString()));  // Well this is completely unreadable.
    }

    public static void main(String[] args) 
    {
        int biggestPalindrome = 0;
        for (int i=100; i<1000; i++)
            for (int j=100; j<1000; j++)
                if (isPalindrome(i*j))
                    if (i*j > biggestPalindrome)
                        biggestPalindrome = (i*j);
        System.out.println(biggestPalindrome);
        
    }

}
