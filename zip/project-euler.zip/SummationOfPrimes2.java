import java.math.*;

public class SummationOfPrimes2
{
    
    public static boolean isPrime(int a)
    {
        for (int i=2; i<a; i++)
            if (a % i == 0)
                return false;
        return true;
    }
 
    public static void main(String[] args)
    {        
        boolean sieve[] = new boolean[2_000_000];
        for (int i=0; i<sieve.length; i++)
            sieve[i] = true;
        
        boolean firstNumber;
        for (int n=2; n<sieve.length; n++)
        {
            firstNumber = true;
            for (int i=n; i<sieve.length; i=i+n)
            {
                if (firstNumber == false)
                    sieve[i] = false;
                firstNumber = false;
            }
        }
        
        BigInteger sum = new BigInteger("0");
        for (int i=2; i<sieve.length; i++)
            if (sieve[i])
                sum = sum.add(BigInteger.valueOf((long)i));
                
        System.out.println("Sum: " + sum);
        
    }

}
