
public class SmallestMultiple 
{

    // "SuperDivisible" means it can be divided by 2 to 20 evenly. 
    public static boolean isSuperDivisible(int a)
    {
        for (int i=2; i<=20; i++)
            if (a % i != 0)
                return false;
        return true;
    }
    
    public static void main(String[] args) 
    {
        int i=21;
        while (!(isSuperDivisible(i)))
            i++;
        
        System.out.println(i);

    }

}
