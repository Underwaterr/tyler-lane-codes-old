
public class TenThousandAndFirstPrime {

    public static boolean isPrime(int a)
    {
        for (int i=2; i<a; i++)
            if (a % i == 0)
                return false;
        return true;
    }
    
    public static void main(String[] args) 
    {
        int i = 2;
        int primeCounter = 1;
        for (; primeCounter<=10001; i++)
            if (isPrime(i))
                primeCounter++;
        
        System.out.println(i-1);    // Minus one is a bit awkard, why?
    }

}
