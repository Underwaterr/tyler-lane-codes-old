
public class Fraction
{
    private final int numerator;
    private final int denominator;

    /*
     *  Constructors
     *      Numerator & denominator taken as arguments
     *      Just numerator as argument, denominator assumed to be 1
     *      Arg is Fraciton object, not two integers
     *  
     *  Arithmetic (Returns Fraction obj. unless noted)
     *      Plus
     *      Subtract
     *      Multiply (two args)
     *      Multiply (three args)
     *      Divide
     *      Equals (returns boolean)
     *  
     *  Other
     *      Euclid_GCF, Finds the GCF of two numbers recursively
     *      
     *  Returns
     *      Get_Numerator
     *      Get_Denominator
     *      toString
     */
    
    
    // Constructor (Automatically reduces)
    public Fraction(int n, int d)
    {
        // First find the GCF of potential numerator & denominator
        int divisor = Euclid_GCF(n, d);
        
        // Then divide both by the GCF
        numerator = n / divisor;
        denominator = d / divisor;
    }
    
    // Constructor (Denominator is assumed to be 1)
    public Fraction(int n)
    {
        numerator = n;
        denominator = 1;
    }
    
    // Constructor that takes a fraction as input
    public Fraction (Fraction f)
    {
        int n = f.Get_Numerator();
        int d = f.Get_Denominator();
        
        // First find the GCF of potential numerator & denominator
        int divisor = Euclid_GCF(n, d);
        
        // Then divide both by the GCF
        int sudo_numerator = n / divisor;
        int sudo_denominator = d / divisor;
        
        if (sudo_denominator < 0)
        {
            numerator = sudo_numerator * -1;
            denominator = sudo_denominator * -1;
        }
        else
        {
            numerator = sudo_numerator;
            denominator = sudo_denominator;
        }
    }
    
    // Adds two fractions!
    public static Fraction Add(Fraction term1, Fraction term2)
    {
        int new_numerator = (term1.Get_Numerator() * term2.Get_Denominator()) + (term2.Get_Numerator() * term1.Get_Denominator());
        int new_denominator = term1.Get_Denominator() * term2.Get_Denominator();
    
        return new Fraction(new_numerator, new_denominator);
    }
    
    // Subtracts two fractions!
    public static Fraction Subtract(Fraction term1, Fraction term2)
    {
        int new_numerator = (term1.Get_Numerator() * term2.Get_Denominator()) - (term2.Get_Numerator() * term1.Get_Denominator());
        int new_denominator = term1.Get_Denominator() * term2.Get_Denominator();
    
        return new Fraction(new_numerator, new_denominator);
    }
    
    // Multiplies two fractions!
    public static Fraction Multiply(Fraction term1, Fraction term2)
    {
        return new Fraction((term1.Get_Numerator() * term2.Get_Numerator()), (term1.Get_Denominator() * term2.Get_Denominator()));
    }
    
    // Multiplies THREE fractions! :O
    public static Fraction Multiply(Fraction term1, Fraction term2, Fraction term3)
    {
        return new Fraction(term1.Get_Numerator() * term2.Get_Numerator() * term3.Get_Numerator(), term1.Get_Denominator() * term2.Get_Denominator() * term3.Get_Denominator());
    }
    
    // Divide two fractions! (Really just multiplies the first fraction by the reciprocal of the second)
    public static Fraction Divide(Fraction term1, Fraction term2)
    {
        return new Fraction((term1.Get_Numerator() * term2.Get_Denominator()), (term1.Get_Denominator() * term2.Get_Numerator()));
    }

    // Check if two fractions are equal
    public static boolean Equals(Fraction term1, Fraction term2)
    {
        // No need to worry since all fractions are automatically reduced
        // Just compare numerators & denominators
        return ((term1.Get_Numerator() == term2.Get_Numerator()) && (term1.Get_Denominator() == term2.Get_Denominator()));
    }
    
    // Find the GCF of two numbers, via Euclid!
    private int Euclid_GCF(int a, int b)
    {
        if (b == 0)
            return a;
        else
            return Euclid_GCF(b, (a%b));
    }
    
    // Return functions
    public int Get_Numerator()      {return numerator;}
    public int Get_Denominator()    {return denominator;}
    
    // toString
    public String toString()
    {
        // Only show the denominator if fraction isn't over 1
        if (denominator == 1)
            return numerator + "";
        else
            return numerator + "/" + denominator;
    }
    
}
