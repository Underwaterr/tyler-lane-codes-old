
public class App
{
    // Demonstrates examples of the Matrix class
    public static void main(String[] args)
    {
        // 12
        // 22   3 rows, 2 columns
        // 32
        
        // Make a new, blank 4x4 matrix
        Matrix tiny = new Matrix (4, 4);
        // Fill it with random integers
        tiny.Become_Random_Int_Matrix(5);
        // Print matrix to console
        System.out.println("Matrix: \n" + tiny + "\n");
        // Convert matrix to Echelon form
        tiny.Echelon_Form();
        // Print to Console
        System.out.println("Matrix in echelon form: \n" + tiny + "\n");
        
        // Create new, blank 3x3 matrix
        Matrix apples = new Matrix (3, 3);
        // Fill with random fractions
        apples.Become_Random_Matrix(5);
        // Print matrix to console
        System.out.println("Apples:");
        System.out.println(apples);
        // Create new, blank 3x3 matrix
        Matrix oranges = new Matrix (3, 3);
        // Fill with random fractions
        oranges.Become_Random_Matrix(5);
        // Print matrix to console
        System.out.println("Oranges:");
        System.out.println(oranges);

        // Add the two matrices & display
        Matrix applorange = Matrix.Add(apples, oranges);
        System.out.println("Apploranges: (apples & oranges added together) \n" + applorange);
     
        // Multiply the two matrices & display
        Matrix orples = Matrix.Multiply(apples, oranges);
        System.out.println("Orples: (Apples times Oranges): \n" + orples);

        // Convert the matrix to Echelon Form
        orples.Echelon_Form();
        System.out.println("Orpleon: (Orples in echelon form) \n" + orples);
        
        // Multiply matrix by scalar
        apples.Multiply_By_Scalar(3);
        System.out.println("Apples * 3");
        System.out.println(apples);
        
        // Swap rows in matrix
        apples.Swap_Row(0, 1);
        System.out.println("Swap row 1 & 2 of Apples: ");
        System.out.println(apples); 
        
        
    }

}
