public class CardApp
{
    public static void main(String[] args)
    {
    	CardsWindow screen = new CardsWindow();
    }
}
