import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class CardsWindow 
{
	private String back = "CardImages/blank.png";
	private JFrame frame = new JFrame();
	private JFrame frame2 = new JFrame();
	private JButton hit_button = new JButton("Hit!");
	private JButton stay_button = new JButton("Stay!");
	private JButton reset_button = new JButton("Deal");

    static JLabel[] Dealer_Card_Slots = new JLabel[7];
    static JLabel[] Player_Card_Slots = new JLabel[7];
    static JLabel[] TextSlot = new JLabel[4];

    JLabel DealerScoreSlot = new JLabel(" Score: " + Game.playerTotal());
    JLabel PlayerScoreSlot = new JLabel(" Score: " + Game.playerTotal());
		
	public CardsWindow()
	{
		// Create the window for the cards
		frame.setTitle("Cards");
		frame.setSize(700,250);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setLayout(new GridLayout(2, 9, 2, 7));
	    frame.setBackground(Color.green);
		frame.setAlwaysOnTop(true);
	    Container con = frame.getContentPane();
	    con.setBackground(Color.green.darker());
		
		// Deactivate buttons
		hit_button.setEnabled(false);
		stay_button.setEnabled(false);
		
		// Create the window for the buttons
		frame2.setTitle("Hit or Stay?!");
		frame2.setSize(400,100);
		frame2.setLayout(new GridLayout(1, 3, 50, 2));
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame2.add(reset_button);
		frame2.add(hit_button);
		frame2.add(stay_button);
		frame2.setVisible(true);
		
		// Hit action assignment
		hit_button.addActionListener(new ActionListener() 
		{
		   public void actionPerformed(ActionEvent event) 
		   {hit_action();}
		});
		
		// Stay action assignment
		stay_button.addActionListener(new ActionListener() 
		{
		   public void actionPerformed(ActionEvent event) 
		   {stay_action();}
		});
		
		// Deal action assignment
		reset_button.addActionListener(new ActionListener() 
		{
		   public void actionPerformed(ActionEvent event) 
		   {reset_action();}
		});
		
		this.display_first();
		
	}

	public void display_first()
	{
		// Initialize each slot.
		
		// Dealer title
		frame.add(TextSlot[0] = new JLabel(" Dealer"));
				
		// Then all of the dealer's possible cards.
		for (int i=0; i<7; i++)
			frame.add(Dealer_Card_Slots[i] = new JLabel(new ImageIcon(back)));

		// Dealer's score 
		frame.add(TextSlot[1] = new JLabel(" Score: "));
		
		// Player title
		frame.add(TextSlot[2] = new JLabel(" Player"));
		
		// All of the player's possible cards
		for (int i=0; i<7; i++)
			frame.add(Player_Card_Slots[i] = new JLabel(new ImageIcon(back)));

		// Player's score
		frame.add(TextSlot[3] = new JLabel(" Score: "));
		
		frame.setVisible(true);
	}

	public void display()
	{
		for (int i=0; i<7; i++)
			Dealer_Card_Slots[i].setIcon(new ImageIcon(back));

	    for (int i=0; i<7; i++)
	    	Player_Card_Slots[i].setIcon(new ImageIcon(back));

		TextSlot[1].setText(" Score: " + Game.dealerTotal());
		TextSlot[3].setText(" Score: " + Game.playerTotal());

		frame.setVisible(true);
	}
	
	public void hit_action()
	{
        Game.playerHit();
        Game.displayPlayerHand();
        
        // Update the player's score
        TextSlot[3].setText(" Score: " + Game.playerTotal());
        
        // If they bust
        if (Game.playerTotal()>21)
        {
    		hit_button.setEnabled(false);
    		stay_button.setEnabled(false);
    		frame2.setTitle("Busted. You lose!");
        }
        else if (Game.playerTotal() == 21)
        {
    		hit_button.setEnabled(false);
    		stay_button.setEnabled(false);
    		frame2.setTitle("You got 21! You win!");
        }
	}
	
	public void stay_action()
	{
        while (Game.dealerTotal()<17)
            Game.dealerHit();

        Game.displayDealerHand();
        
        // Update the dealer's score
        TextSlot[1].setText(" Score: " + Game.dealerTotal());

        // If the dealer busts
        if (Game.dealerTotal()>21)
        {
    		hit_button.setEnabled(false);
    		stay_button.setEnabled(false);
    		frame2.setTitle("Dealer busted. You win!");
        }
        else if (Game.dealerTotal()>=Game.playerTotal())
        {
    		hit_button.setEnabled(false);
    		stay_button.setEnabled(false);
    		frame2.setTitle("You lose!");
        }
        else if (Game.dealerTotal()<Game.playerTotal())
        {
    		hit_button.setEnabled(false);
    		stay_button.setEnabled(false);
    		frame2.setTitle("You win!");
        }
      
	}
	
	public void reset_action()
	{
		Game blackjack = new Game();
		
		this.display();
		
		// Restore hit & stay buttons
		hit_button.setEnabled(true);
		stay_button.setEnabled(true);
		frame2.setTitle("Hit or Stay?!");
		
		Game.displayDealerHand();
		Game.displayPlayerHand();
	}

	
	public static void DealerCardSet(int index, ImageIcon image)
	{
		Dealer_Card_Slots[index].setIcon(image);
	}
	
	public static void PlayerCardSet(int index, ImageIcon image)
	{
		Player_Card_Slots[index].setIcon(image);
	}
}
