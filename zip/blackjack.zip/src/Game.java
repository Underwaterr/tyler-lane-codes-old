import java.util.Scanner;
import javax.swing.ImageIcon;

public class Game
{
    // Create a reference to a deck!
	static CardStack deck;
  
    // For user input
    Scanner scan = new Scanner(System.in);
  
    // Create the hands
    static Card playerHand[] = new Card[7];
    static Card dealerHand[] = new Card[7];
    static int playerHandSize = 0, dealerHandSize = 0;
    boolean playerWon;

    // Start a game of BlackJack!
    public Game()
    {
        System.out.println("Starting a new game of BlackJack!");
        powerBar();
      
        // Create a new deck
        deck = new CardStack();
        // Shuffle the deck
        deck.shuffle();
      
        // Draw two cards for the player
        playerHand[0] = deck.pop();
        playerHand[1] = deck.pop();
        playerHandSize = 2;

        // Draw two cards for the dealer
        dealerHand[0] = deck.pop();
        dealerHand[1] = deck.pop();
        dealerHandSize = 2;
    }
  

    
    
    // Play a new round of BlackJack!
    // Returns "false" if the player loses
    public boolean round()
    {
        // Display the dealer's and player's hands
        displayDealerHand();
        displayPlayerHand();
      
        // Keep doing the player's turn until it's over
        //playerTurn returns false when their turn is over.
        while(playerTurn());

        //If the player didn't bust or hit 21, do the dealer's turn
        if (playerTotal()<21)
        {
            dealerTurn();
            displayDealerHand();
        }
       
        // Now check who the winner is!
       
        // If player's score exceeds 21, player loses
        if (playerTotal() > 21)
            return false;

        // If dealer's score exceeds 21, player wins
        if (dealerTotal() > 21)
            return true;
       
        // If the player holds seven cards he wins
        if (playerHandSize >= 7)
            return true;
       
        // If the player's hand is equal to 21 then the player wins
        if (playerTotal() == 21)
            return true;


        // If the player's hand is less than or equal to the dealers, the player loses
        if (playerTotal() <= dealerTotal())
            return false;

        else
            return true;
    }
  
    // Player's turn
    public boolean playerTurn()
    {
        powerBar();

        // Display the player's possible options
        System.out.print("1) Hit or 2) Stay?: ");
        int input = scan.nextInt();
      
        // If they chose to hit
        if (input==1)
        {
            // Hit!
            playerHit();
          
            // Show the player's hand
            displayPlayerHand();
          
            // If they bust
            if (playerTotal()>21)
            {
                // Then their turn is over.
                System.out.println("Bust!\n");
                return false;
            }
          
            // If they do not bust
            else
            {
                // Then their turn is not over.
                return true;
            }
        }  
      
        // If they chose to stay
        else if (input==2)
        {
            System.out.println("Stay!");
            // Their round is over
            return false;
        }
      
        // Anything else is invalid!
        else
        {
            System.out.println("Invalid answer, try again.");
            return true;
        }
    }      

    // Dealer's turn!
    public void dealerTurn()
    {
        // Keep hitting until dealer goes over 16 or the player already busted.

        while (dealerTotal()<17)

            dealerHit();
    }
  
    // Hit me!
    public static void playerHit()
    {
        // Add another card to the player's hand
        playerHand[playerHandSize] = deck.pop();
        playerHandSize++;
    }
  
    // Dealer hits
    public static void dealerHit()
    {
        // Add another card to the dealer's hand
        dealerHand[dealerHandSize] = deck.pop();
        dealerHandSize++;
    }
  

  
    // Displays the dealer's hand
    public static void displayDealerHand()
    {
        System.out.println("Dealer's Hand: (Value: " + dealerTotal() + ")");
        // For each card in the dealer's hand
        for (int i=0; i<dealerHandSize; i++)
        {
            System.out.print("[" + dealerHand[i] + "] ");
        	CardsWindow.DealerCardSet(i, new ImageIcon(dealerHand[i].stringy()));
        }
        System.out.println();

        
    }
  
    // Displays the player's hand
    public static void displayPlayerHand()
    {
        System.out.println("Player's Hand: (Value: " + playerTotal() + ")");
        // For each card in the player's hand
        for (int i=0; i<playerHandSize; i++)
        {
            System.out.print("[" + playerHand[i] + "] ");
    		CardsWindow.PlayerCardSet(i, new ImageIcon(playerHand[i].stringy()));
        }
        System.out.println();
    }
  
  
    // Returns the total of the dealer's hand
    public static int dealerTotal()
    {
        int dealerHandTotal = 0;
        // Add up all the dealer's cards
        for (int i=0; i<dealerHandSize; i++)
            dealerHandTotal += dealerHand[i].getPoints();
          
        return (dealerHandTotal);
    }
  
    // Returns the total of the player's hand
    public static int playerTotal()
    {
        int playerHandTotal = 0;
        // Add up all the player's cards
        for (int i=0; i<playerHandSize; i++)
            playerHandTotal += playerHand[i].getPoints();
          
        return (playerHandTotal);
    }
  
    // Display the POWER BAAAAARRRRR
    // For MAXIMUM ORGANIZATION
    public void powerBar()
    {
        System.out.println("--------------------------------------------");
    }

}