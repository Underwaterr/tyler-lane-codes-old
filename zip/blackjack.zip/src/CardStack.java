import java.util.Random;

class CardStack
{
    int NUMBER_OF_DECKS = 1;
    int deck_size = (NUMBER_OF_DECKS * 52);
   
    // Create an array of cards called deck
    private Card deck[] = new Card[deck_size];
    private int top;
   
    // Constructor
    public CardStack()
    {
        top = -1;
       
        for (int j=0; j<NUMBER_OF_DECKS; j++)
        {
            // Create Clubs
            for (int i=1; i<=13; i++)
                this.push (i, 'C');
               
            // Create Diamonds
            for (int i=1; i<=13; i++)
                this.push (i, 'D');
   
            // Create Hearts
            for (int i=1; i<=13; i++)
                this.push (i, 'H');
           
            // Create Spades
            for (int i=1; i<=13; i++)
                this.push (i, 'S');
        }
    }
   
    // Push card onto the stack
    public void push (int v, char s)
    {
        // Don't exceed the deck size!
        if (top+1 == deck.length)
            System.out.println("Deck full!");
        else
            deck[++top] = new Card(v, s);
    }
   
    // Pop a card off the stack
    public Card pop ()
    {
        // Check if the deck is empty
        if (this.isEmpty())
        {
            System.out.print("Deck is empty! ");
            return null;
        }
        else
            return deck[top--];
    }

    // Shuffle cards in the deck
    public void shuffle ()
    {
        // Create a random number generator
        Random random_generator = new Random();

        // For each card in the deck
        for (int i=0; i<=top; i++)
        {
            // Create a random number
            int random_number = random_generator.nextInt(top);   
            // Copy first card in a temporary spot
            Card temp = this.deck[i];
            // Copy second card into where first card was
            this.deck[i] = this.deck[random_number];
            // Copy temporary card into where the second card was
            this.deck[random_number] = temp;
        }
       
    }
   
    // Check if deck is empty
    public boolean isEmpty()
    {
        return (top == -1);
    }
   
} 