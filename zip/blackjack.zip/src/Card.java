public class Card
{  
    private int value, points;
    /* Card values & points
     *      1    (Ace)    1 or 10 points
     *      2             2 points
     *      3             3 points
     *      4             4 points
     *      5             5 points
     *      6             6 points
     *      7             7 points
     *      8             8 points
     *      9             9 points
     *      10            10 points
     *      11    (Jack)  10 points
     *      12    (Queen) 10 points
     *      13    (King)  10 points
     */

    private char suit;
    /* Card suits
     *        'C' =    Clubs
     *        'D' =    Diamonds
     *        'H' =    Hearts       
     *        'S' =    Spades
     */
   
    // Constructor
    public Card (int num, char ch)
    {
        // Set the card's value
        value = num;
        // Set the card's suit
        suit = ch;

        // Set how many points the card is worth
        if (value<10)
            points = value;
        else
            points = 10;
    }
   
    // Get suit
    public char getSuit()
    {
        return suit;
    }
   
    // Get value
    public int getValue()
    {
    	return value;
    }
    
    // Get points
    public int getPoints()
    {
    	return points;
    }   
    
    public String stringy()
    {
    	// Returns "CardImages/" + [suit_string] + [card value] + ".png"
    	String suit_string = "";
    	
    	switch (suit)
    	{
            case 'C':    suit_string = "c";  break;
            case 'D':    suit_string = "d";  break;
            case 'H':    suit_string = "h";  break;
            case 'S':    suit_string = "s";  break;
        }
    	
    	return ("CardImages/" + suit_string + value + ".png");
    }
    
    // toString
    public String toString()
    {
        String value_string = "";
        String suit_string = "";
   
        // Convert suit to String
        switch (suit)
        {
            case 'C':    suit_string = "Clubs";      break;
            case 'D':    suit_string = "Diamonds";   break;
            case 'H':    suit_string = "Hearts";     break;
            case 'S':    suit_string = "Spades";     break;
        }
       
        // Convert value to String, concatenate string with suit
        switch (value)
        {
            case  1: value_string = ("Ace of "    + suit_string);    break;
            case  2: value_string = ("2 of "      + suit_string);    break;
            case  3: value_string = ("3 of "      + suit_string);    break;
            case  4: value_string = ("4 of "      + suit_string);    break;
            case  5: value_string = ("5 of "      + suit_string);    break;
            case  6: value_string = ("6 of "      + suit_string);    break;
            case  7: value_string = ("7 of "      + suit_string);    break;
            case  8: value_string = ("8 of "      + suit_string);    break;
            case  9: value_string = ("9 of "      + suit_string);    break;
            case 10: value_string = ("10 of "     + suit_string);    break;
            case 11: value_string = ("Jack of "   + suit_string);    break;
            case 12: value_string = ("Queen of "  + suit_string);    break;
            case 13: value_string = ("King of "   + suit_string);    break;
        }
       
        return(value_string);
    }
   

}
